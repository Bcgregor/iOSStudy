//
//  ViewController.swift
//  Firebase101
//
//  Created by 이재백 on 2020/11/22.
//

import UIKit
import Firebase

class ViewController: UIViewController {
    
    @IBOutlet weak var dataLabel: UILabel!
    @IBOutlet weak var numOfCustomers: UILabel!
    
    let db = Database.database().reference()
    
    var customers: [Customer] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Update UILabel
        updateLabel()
        
        // Write Data Sample
        saveBasicType()
        
        // Write Data Customers
//        saveCustomers()
         
        // Read Data
        fetchCustomers()
        
        // Update, Delete Data
//        updateBasicTypes()
//        deleteBasicTypes()
    }
    @IBAction func createCustomer(_ sender: Any) {
        saveCustomers()
    }
    @IBAction func fetchCustomer(_ sender: Any) {
        fetchCustomers()
    }
    
    func updateCustomers() {
        guard customers.isEmpty == false else { return }
        customers[0].name = "changed name"
        
        let dictionary = customers.map { $0.toDictionary }
        db.updateChildValues(["customers": dictionary  ])
    }
    
    func deleteCustomers() {
        db.child("customers").removeValue()
    }
    
    @IBAction func updateCustomer(_ sender: Any) {
        updateCustomers()
    }
    
    
    @IBAction func deleteCustomer(_ sender: Any) {
        deleteCustomers()
    }
}

// MARK: 데이터베이스에 데이터 추가하기
extension ViewController {
    func saveBasicType() {
        // ref: self.ref.child("users").child(user.uid).setValue(["username": username])
        // - NSString, NSNumber, NSDictionary. NSArray
        
        db.child("int").setValue(3)
        db.child("double").setValue(3.5)
        db.child("str").setValue("string value - 안녕하세요")
        db.child("array").setValue(["a", "b", "c"])
        db.child("dict").setValue(["id": "anyID", "age": 10, "city": "daegu" ])
    }
    
    func saveCustomers() {
        // To do
        // - 여기는 책 가게이며, 회원 등록을 하고 싶다
        // - Customer 모델에다 저장할 것이고, 각 고객들은 [Book]을 가지고 있다
        
        let books = [Book(title: "Good to Great", author: "Somebody"), Book(title: "Hacking Growth", author: "Somebody")]
        let customer1 = Customer(id: "\(Customer.id)", name: "Son", books: books)
        Customer.id += 1
        let customer2 = Customer(id: "\(Customer.id)", name: "JB", books: books)
        Customer.id += 1
        let customer3 = Customer(id: "\(Customer.id)", name: "SR", books: books)
        Customer.id += 1
    
        db.child("customers").child(customer1.id).setValue(customer1.toDictionary)
        db.child("customers").child(customer2.id).setValue(customer2.toDictionary)
        db.child("customers").child(customer3.id).setValue(customer3.toDictionary)

    }
    
    func updateLabel() {
        db.child("firstData").observeSingleEvent(of: .value) { snapshot in
            print("---> snapshot: \(snapshot)")
            
            let value = snapshot.value as? String ?? ""
            DispatchQueue.main.async {
                self.dataLabel.text = value
            }
        }
    } // end func updateLabel()

} // end extension ViewController

// MARK: 데이터베이스의 데이터를 파싱해오기, UI에 업데이트 하기 [ Read(Fetch) Data ]
extension ViewController {
    func fetchCustomers() {
        db.child("customers").observeSingleEvent(of: .value) { snapshot in
            print("---> snapshot.value in featchCustomers: \(snapshot.value)")
            
            do {
                let data = try JSONSerialization.data(withJSONObject: snapshot.value, options: [])
                let decoder = JSONDecoder()
                let customers: [Customer] = try decoder.decode([Customer].self, from: data)
                // 현재 customers 정보를 저장해두었다가, update, delete 시 사용할 예정
                self.customers = customers
                DispatchQueue.main.async {
                    self.numOfCustomers.text = "# of Customers: \(customers.count)"
                }
//                print("---> customers.count: \(customers.count)")                
            } catch let error {
                print("---> error: \(error.localizedDescription)")
            }
        }
    }
}

// MARK: 데이터베이스의 데이터를 업데이트하고, 삭제하기
extension ViewController {
    func updateBasicTypes() {
//        현재 들어있는 값에 대한 걸 알기 위해서 그냥 참조용으로 적어둔 것
//        db.child("int").setValue(3)
//        db.child("double").setValue(3.5)
//        db.child("str").setValue("string value - 안녕하세요")
        
        db.updateChildValues(["int": 6])
        db.updateChildValues(["double": 5.4])
        db.updateChildValues(["str": "changed value - Hello~:)"])
    }
    
    func deleteBasicTypes() {
        db.child("int").removeValue()
        db.child("double").removeValue()
        db.child("str").removeValue()
    }
}

struct Customer: Codable  {
    let id: String
    var name: String
    let books: [Book]
    
    var toDictionary: [String: Any] {
        let booksArray = books.map { $0.toDictionary }
//        var booksArray: [[String: Any]] = []
//        for book in books {
//            booksArray.append(book.toDictionary)
//        }
        print("books in Customer: \(books)")
        print("booksArray in Customer: \(booksArray)")
        let dict: [String: Any] = ["id": id, "name": name, "books": booksArray]
        print("dict in Customer: \(dict)")
        return dict
    }
    
    static var id: Int = 0
}

struct Book: Codable {
    let title: String
    let author: String
    
    var toDictionary: [String: Any] {
        let dict: [String: Any] = ["title": title, "author": author]
        print("dict in Book: \(dict)")
        return dict
    }
}
