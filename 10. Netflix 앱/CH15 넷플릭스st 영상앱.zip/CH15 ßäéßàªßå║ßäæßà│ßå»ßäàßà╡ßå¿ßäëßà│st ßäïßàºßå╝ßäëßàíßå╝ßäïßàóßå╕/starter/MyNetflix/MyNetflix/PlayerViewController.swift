//
//  PlayerViewController.swift
//  MyNetflix
//
//  Created by joonwon lee on 2020/04/01.
//  Copyright © 2020 com.joonwon. All rights reserved.
//

import UIKit
import AVFoundation

class PlayerViewController: UIViewController {
    
    @IBOutlet weak var controlView: UIView!
    @IBOutlet weak var playerView: PlayerView!
    @IBOutlet weak var playButton: UIButton!
    
    let player = AVPlayer()
    
    // 강제 landscape 를 위해서 사용
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return .landscapeRight
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        playerView.player = player
//        let value = UIInterfaceOrientation.landscapeRight.rawValue
//        UIDevice.current.setValue(value, forKey: "orientation")
        
        // [o] 코드로도 만들어보고 싶당
        let pauseImage = UIImage(systemName: "pause.fill")
        playButton.setImage(pauseImage, for: .selected)
    }
    
//     shouldAutorotate 의 값이 true 를 반환할 때만, supportedInterfaceOrientations 메소드가 불려온다.
//     즉, 둘은 하나다!
//    override var shouldAutorotate: Bool {
//        return true
//    }
    
    // viewDidLoad() 는 메모리에 올라왔을 때
    // viewWillAppear(_:) 는 화면에 실제로 뷰가 뿌려지기 직전
    // 그 후에는 view가 화면에 뿌려져으니 viewDidAppear(_:) 가 불린다
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        // 사용자가 SearchViewController 에서 영화를 클릭해서!
        // 플레이어에 들어오면 바로 시작을 하게끔
        play()
    }
    
    
    @IBAction func togglePlayButton(_ sender: Any) {
        if player.isPlaying {
            pause()
        } else {
            play()
        }
    }
    
    func play() {
        player.play()
        playButton.isSelected = true // 재생 중이니 선택되어서 퍼즈 이미지가 보여야 함
    }
    
    func pause() {
        player.pause()
        playButton.isSelected = false
    }
    
    func reset() {
        pause()
        player.replaceCurrentItem(with: nil)
    }
    
    @IBAction func closeButtonTapped(_ sender: Any) {
        reset()
        dismiss(animated: false, completion: nil)
    }
}

extension AVPlayer {
    var isPlaying: Bool {
        // != nil -> nil이 아니라면, 즉 현재 재생 목록에 아이템이 들어있다면!
        // 그 아이템의 rate, 즉 재생 중인지 아닌지를 보는 것이다. 0이 아니라면 재생 중일 것
        // 따라서 이 경우 자연스럽게 return true 하면 된다
        guard self.currentItem != nil else { return false }
        return self.rate != 0
    }
}
