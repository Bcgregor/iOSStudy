//
//  PlayerViewController.swift
//  MyNetflix
//
//  Created by joonwon lee on 2020/04/01.
//  Copyright © 2020 com.joonwon. All rights reserved.
//

import UIKit
import AVFoundation

class PlayerViewController: UIViewController {
    
    @IBOutlet weak var controlView: UIView!
    @IBOutlet weak var playerView: PlayerView!
    @IBOutlet weak var playButton: UIButton!
    
    let player = AVPlayer()
    
    // 강제 landscape 를 위해서 사용
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return .landscapeRight
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        let value = UIInterfaceOrientation.landscapeRight.rawValue
//        UIDevice.current.setValue(value, forKey: "orientation")
    }
    
//     shouldAutorotate 의 값이 true 를 반환할 때만, supportedInterfaceOrientations 메소드가 불려온다.
//     즉, 둘은 하나다!
//    override var shouldAutorotate: Bool {
//        return true
//    }
    
    
    @IBAction func togglePlayButton(_ sender: Any) {
        playButton.isSelected = !playButton.isSelected
        
        // 코드로도 만들어보고 싶당
//        let xmarkImage = UIImage(systemName: "xmark.fill")
//        playButton.image
        // playButton.image(for: .selected)
    }
    

    @IBAction func closeButtonTapped(_ sender: Any) {
        dismiss(animated: false, completion: nil)
    }
}

extension AVPlayer {
    var isPlaying: Bool {
        // != nil -> nil이 아니라면, 즉 현재 재생 목록에 아이템이 들어있다면!
        // 그 아이템의 rate, 즉 재생 중인지 아닌지를 보는 것이다. 0이 아니라면 재생 중일 것
        // 따라서 이 경우 자연스럽게 return true 하면 된다
        guard self.currentItem != nil else { return false }
        return self.rate != 0
    }
}
