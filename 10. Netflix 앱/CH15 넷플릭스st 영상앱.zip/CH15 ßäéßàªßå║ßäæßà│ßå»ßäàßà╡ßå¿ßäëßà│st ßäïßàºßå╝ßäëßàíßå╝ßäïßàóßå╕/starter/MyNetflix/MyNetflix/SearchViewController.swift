//
//  SearchViewController.swift
//  MyNetflix
//
//  Created by joonwon lee on 2020/04/02.
//  Copyright © 2020 com.joonwon. All rights reserved.
//

import UIKit
import Kingfisher
import AVFoundation
 
class SearchViewController: UIViewController {

    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var resultCollectionView: UICollectionView!
    
    // MVVM 패턴에 따르면, ViewModel 을 생성 후, ViewModel 로부터 데이터를 받아와야 하지만,
    // 이번에는 새로운 것들을(URLSession, Decoding, Player, ...) 많이 하니, 복잡할 수 있어서 넘어감!
    var movies: [Movie] = []
    
    @IBAction func tapBG(_ sender: Any) {
        searchBar.resignFirstResponder()
    }
}

extension SearchViewController: UICollectionViewDataSource {
    // 몇 개 넘어온다고?
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return movies.count
    }
    // 어떻게 표현한다고?
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        guard let cell =  collectionView.dequeueReusableCell(withReuseIdentifier: "ResultCell", for: indexPath) as? ResultCell else { return UICollectionViewCell() }
    
        let movie = movies[indexPath.item]
        // To Do
        // - thumbnail path (string 형태로 저장되어있는 서버 내의 url) -> image
        // 구현 방법1: 인터넷에 검색해서 임의로 해결
//        let imageUrl = URL(string: movie.thumbnailPath)!
//        do {
//            let imageData = try Data(contentsOf: imageUrl)
//            cell.movieThumbnail.image = UIImage(data: imageData)
//        } catch let error {
//            print("error message: \(error.localizedDescription)")
//        }
        
        // 구현 방법2: 써드파티(외부 코드 가져다쓰기)를 이용
        // Open Source 가져오는 방법?
        // SPM(Swift Package Manager), Cocoa Pod, Carthage
        // 이번 강의에서는 SPM 을 사용
        let imageUrl2 = URL(string: movie.thumbnailPath)!
        cell.movieThumbnail.kf.setImage(with: imageUrl2)
        
//        UI update 하기 전에 cell 이 제대로 생성되었고, DelegateFlowLayout 내부의 함수에서 크기가 제대로 설정되었는지 확인하기 위해
//        배경색을 바꾸어보았던 것
//        cell.backgroundColor = UIColor.lightGray
        return cell
    }
}

extension SearchViewController: UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        // To Do
        // movie 받기, player vc 만들기
        // - player vc 를 띄우면서(by using present method), player vc 에 movie 객체를 전달
        
//         Collection View Atrribute 중에 3가지 옵션이 있는데,
//         그걸 코드로 구현하면 아래와 같이 된다.
//         UITableView, UICollectionView 는 UIScrollView 를 상속받기 때문에
//         open var keyboardDismissMode: UIScrollView.KeyboardDismissMode 선언이 되어있다
//         당연히 default 는 none 이다.
//         이렇게 미리 선언되어있고, 거기에 타입까지 정해져있으니 사실 값을 할당할 때 .onDrag 와 같이 바로 값을 입력하는 것이 가능하다
        collectionView.keyboardDismissMode = UIScrollView.KeyboardDismissMode.onDrag
        
        let movie = movies[indexPath.item]
        let url = URL(string: movie.previewURL)!
        let item = AVPlayerItem(url: url)

        let playerStoryboard = UIStoryboard.init(name: "Player", bundle: nil)
        let playerVC = playerStoryboard.instantiateViewController(identifier: "PlayerViewController") as! PlayerViewController
//        print("---> playerVC.modalTransitionStyle.rawValue: \(playerVC.modalTransitionStyle.rawValue)")
        playerVC.modalTransitionStyle = .crossDissolve
        playerVC.modalPresentationStyle = .fullScreen
//        playerVC.definesPresentationContext = true
//        self.definesPresentationContext = true
        
        playerVC.player.replaceCurrentItem(with: item)        
        present(playerVC, animated: false, completion: nil)
        
    }
}

extension SearchViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let margin: CGFloat = 8
        let itemSpacing: CGFloat = 10
        
        let width = (collectionView.bounds.width - margin * 2 - itemSpacing * 2) / 3
        let height = width * 10/7
        
        return CGSize(width: width, height: height)
    }
}

class ResultCell: UICollectionViewCell {
    @IBOutlet weak var movieThumbnail: UIImageView!
}



extension SearchViewController: UISearchBarDelegate {
    
    private func dismissKeyboard() {
        searchBar.resignFirstResponder()
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        // Search 버튼이 클릭되었을 때 검색이 시작되도록 설계
        // - TO DO
        // - 키보드 사용이 끝나면 사라지도록 할 것
        dismissKeyboard()
        
        // - 검색어가 있는지, 없다면 입력되지 않도록 방지
        guard let searchTerm = searchBar.text, searchTerm.isEmpty == false else { return }
        
        // 검색어가 UISearchBar 를 통해 잘 들어오는지 확인
        print("---> 검색어: \(searchTerm)")
        
        // - 네트워킹을 통한 검색
        //   + [o] 입력된 검색어 searchTerm 을 가지고, 영화 검색할 것
        //     + [o] 이를 위해선 검색API 가 필요
        //     + [o] 검색 결과를 받아올 모델이 필요함
        //       + [o] 서버에서 JSON 파일로부터 긁어올 Response 객체와 실제로 사용할 Movie 객체가 필요
        //   + 결과를 받아와서 CollectionView 로 표현할 것
        
        SearchAPI.search(searchTerm) { movies in
            // 넘겨오는 [Movie] 를 가지고 collectionView 로 표현하기
            
//             일단 데이터가 잘 넘어오는지 확인
            print("---> 몇개 넘어왔어? \(movies.count), 첫번째 객체 제목 \(movies.first?.title)")
            // 네트워킹 작업은 느린 작업이다.
            // 따라서 메인 스레드가 아닌 기타 스레드에서 작업 중이었으므로,
            // UICollectionView.reloadData() 는 UI API 이므로 메인 스레드에서 작업해주어야 한다
            // 따라서 디스패치 큐에 태워 메인 스레드로 보낸다
            DispatchQueue.main.async {
                self.movies = movies
                self.resultCollectionView.reloadData()
            }
        } // end SearchAPI.search(term:completion:)
    } // end func searchBarSearchButtonClicked
} // end extension SearchViewController: UISearchBarDelegate

// 검색API
// @escaping: completion 안에 있는 코드 블록이, 해당 메소드의 작업이 끝난 후에 실행되고 싶을 떄!
// 즉, cmpletion 뒤에 오는 Closure 를 Escaping Closure 로 만들고 싶을 때!
// (completion 뒤에 오는 Closure 를 아에 { } 이런식으로 표현할 때 Trailing Closure 라고 함)
class SearchAPI {
    // Instance Method 가 아닌, Type Method
    // Instance Method 는 Instance 가 생성되어야지만 사용할 수 있다
    // Type Method 는 Instance 를 생성하지 않아도, Type에 바로 접근하여 사용이 가능하다
    static func search(_ term: String, completion: @escaping ([Movie]) -> Void) {
        // HTTP 를 이용한 네트워킹은 URLSession 으로 한다
        // URLSession 은 URLSessionConfiguration 를 이용해서 생성한다
        // 생성된 URLSession 은 URLSessionTask 를 만들어서 실제로 서버와의 통신을 한다
        // URLSessionTask 에는 data, upload, download 3가지 task 가 존재한다
        
//        let configuration = URLSessionConfiguration.default
//        let session = URLSession(configuration: configuration)
        let session = URLSession(configuration: .default)
        var urlComponents = URLComponents(string: "https://itunes.apple.com/search?")!
        let mediaQuery = URLQueryItem(name: "media", value: "movie")
        let entityQuery = URLQueryItem(name: "entity", value: "movie")
        let termQuery = URLQueryItem(name: "term", value: term)
        urlComponents.queryItems?.append(mediaQuery)
        urlComponents.queryItems?.append(entityQuery)
        urlComponents.queryItems?.append(termQuery)
        
        let requestURL = urlComponents.url!
        
        let dataTask = session.dataTask(with: requestURL) { data, response, error in
            let successRange = 200..<300
            guard error == nil,
                  let statusCode = (response as? HTTPURLResponse)?.statusCode,
                  successRange.contains(statusCode) else {
                // 문제가 있는 경우에는 search 메소드에 들어오는 completion 에 Movie 객체가 없다고 알려줌
                completion([])
                return
            }
            
            guard let resultData = data else {
                // 마찬가지로 문제가 있는 경우에는 빈 어레이를 넘겨주면 된다ez
                completion([])
                return
            }
            
            // 서버로부터 받아온 resultData 는 Data 타입이다
            // Data 타입은 우리가 알아먹을 수 없는 정보다
            // 고로, 우리가 이 Data 타입 내부의 데이터를 확인하려면 알아볼 수 있는 utf8 로 변환해서 확인해야한다
            // 물론 utf8 로 변환하는 건 내용을 보기 위함이지, 우리의 궁극적인 목표는 Data 타입의 resultData 를 [Movie] 로 파싱하는 것이다
            
//            우리가 알아볼 수 있는 데이터로 변환하는 작업
//            이 utf8 로 만든 데이터는 실제 파싱하는 데에선 사용하지 않음
//            let resultString = String(data: resultData, encoding: .utf8)
//            print("---> response data encoding utf8 from Data type: \(resultString)")
            
            let movies = SearchAPI.parseMovies(resultData)
            completion(movies)
//            print("---> movie's count: \(movies.count)")
            
            
        } // end completion dataTask's
        
        // dataTask 를 네트워킹을 시작!
        dataTask.resume()
    } // end func search
    
    // ✔ limit: method 10 line, class 200 line // beginer: 30, 400 line
    
    // 위의 규칙을 지키기 위해서 decoder 기능을 수행하는 부분을 메소드로 빼낸다.
    static func parseMovies(_ data: Data) -> [Movie] {
        let decoder = JSONDecoder()
        
        do {
            let response = try decoder.decode(Response.self, from: data)
            let movies = response.movies
            return movies
        } catch let error {
            print("---> parsing error message: \(error.localizedDescription)")
            return []
        }
    } // end func parseMovies
} // end class SearchAPI 

// 서버에서 JSON 형태로 존재할 데이터들을 받아올 객체
struct Response: Codable {
    let resultCount: Int
    let movies: [Movie]
    
    enum CodingKeys: String, CodingKey {
        case resultCount
        case movies = "results"
    }

}

// 받아온 Response 를 가지고, 우리가 원하는 데이터 형태로 변화해줄 객체
struct Movie: Codable {
    let title: String
    let director: String
    let thumbnailPath: String
    let previewURL: String
    
    enum CodingKeys: String, CodingKey {
        case title = "trackName"
        case director = "artistName"
        case thumbnailPath = "artworkUrl100"
        case previewURL = "previewUrl"
    }
}
